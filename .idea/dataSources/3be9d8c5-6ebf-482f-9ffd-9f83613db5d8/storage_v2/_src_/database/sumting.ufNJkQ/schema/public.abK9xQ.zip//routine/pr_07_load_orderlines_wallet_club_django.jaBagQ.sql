create procedure pr_07_load_orderlines_wallet_club_django()
    language sql
as
$$
-- INCREMENTAL
INSERT INTO public.pr_orderline_wallet_club(
	notes, 
	orderline_id_ext,
	orderline_id_ext_long, 
	created_at, 
	updated_at,
	order_key,
	order_id_ext,  
	wallet_key, 
	amount_total, 
	wallet_is_updated)
	

SELECT 	
	ol.notes,
	ol.id,
	ol.stripe_line_item_id,
	ol.created_at,
	ol.updated_at,
	ord.order_key,
	ol.order_id,
	wal.wallet_key,
	cast(ol.amount as float) as amount_total,
	'0' as has_wallet_updated
FROM lz_orders_orderitem   ol
INNER JOIN pr_order ord
	ON ol.order_id=ord.order_id_ext
INNER JOIN lz_products_product pr
	ON pr.id=ol.product_id
INNER JOIN pr_wallet wal
	ON wal.payer_key=ord.payer_key
LEFT JOIN pr_orderline_wallet_club cl 
	ON ol.order_id=cl.order_id_ext
WHERE ord.order_type_key=1
	AND lower(pr.title) LIKE '%club%'
	AND cl.order_id_ext IS NULL


$$;

alter procedure pr_07_load_orderlines_wallet_club_django() owner to sumting;

