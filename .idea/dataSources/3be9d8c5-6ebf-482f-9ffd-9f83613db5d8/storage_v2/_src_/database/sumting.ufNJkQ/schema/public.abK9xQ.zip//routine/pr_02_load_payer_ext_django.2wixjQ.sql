create procedure pr_02_load_payer_ext_django()
    language sql
as
$$
-- INCREMENTAL
INSERT INTO public.pr_payer_ext(
	 
	payer_id_ext, 
	payer_id_ext_long, 
	created_at, 
	updated_at, 
	payer_key) 
	
SELECT 

	customer_id,
	stripe_customer_id , 
	cus.created_at, 
	cus.updated_at,
	pay.payer_key
FROM public.lz_customers_stripecustomer cus
INNER JOIN public.pr_payer pay
ON cus.customer_id=pay.payer_id_ext
LEFT JOIN public.pr_payer_ext pay_ext
ON pay_ext.payer_id_ext_long= cus.stripe_customer_id
WHERE pay_ext.payer_id_ext_long IS NULL ;
$$;

alter procedure pr_02_load_payer_ext_django() owner to sumting;

