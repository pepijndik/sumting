create procedure pr_10_load_orderlines_xxx_dump()
    language sql
as
$$
INSERT INTO public.pr_orderline_xxx_dump(
	id, 
	notes, 
	order_id, 
	product_id, 
	stripe_line_item_id, 
	unit_reference_in_line_item, 
	quantity, 
	batch_id, 
	is_order_confirmation_sent, 
	created_at, 
	updated_at, 
	amount, 
	currency)  
SELECT 	
	 ol.id, 
	 ol.notes, 
	 ol.order_id, 
	 ol.product_id, 
	 ol.stripe_line_item_id, 
	 ol.unit_reference_in_line_item, 
	 ol.quantity, 
	 ol.batch_id, 
	 ol.is_order_confirmation_sent, 
	 ol.created_at, 
	 ol.updated_at, 
	 ol.amount, 
	 ol.currency
	
FROM lz_orders_orderitem   ol
LEFT JOIN pr_order ord
	ON ol.order_id=ord.order_id_ext
LEFT JOIN lz_products_product pr
	ON pr.id=ol.product_id
LEFT JOIN public.pr_orderline_xxx_dump dump
	ON dump.stripe_line_item_id=ol.stripe_line_item_id

WHERE dump.stripe_line_item_id IS NULL
	AND (ord.order_id_ext IS NULL
		OR pr.id IS NULL
		OR ord.payer_key IS NULL
		OR ol.amount IS NULL)

$$;

alter procedure pr_10_load_orderlines_xxx_dump() owner to sumting;

