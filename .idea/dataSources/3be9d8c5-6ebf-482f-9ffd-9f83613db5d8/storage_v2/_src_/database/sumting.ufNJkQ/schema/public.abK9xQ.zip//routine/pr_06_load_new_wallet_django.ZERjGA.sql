create procedure pr_06_load_new_wallet_django()
    language sql
as
$$
-- INCREMENTAL
INSERT INTO public.pr_wallet(
	balance,
	 created_at,
	 payer_key,
	 number_total) 

SELECT 	distinct 
	0.0as balance,
	NOW(),
	ord.payer_key,
	0 as number_total
FROM lz_orders_orderitem   ol

INNER JOIN pr_order ord
	ON ol.order_id=ord.order_id_ext

INNER JOIN lz_products_product pr
	ON pr.id=ol.product_id
LEFT JOIN pr_wallet wal
	ON wal.payer_key=ord.payer_key
WHERE ord.order_type_key=1
	AND lower(pr.title) LIKE '%club%'
	AND wal.payer_key is NULL

$$;

alter procedure pr_06_load_new_wallet_django() owner to sumting;

