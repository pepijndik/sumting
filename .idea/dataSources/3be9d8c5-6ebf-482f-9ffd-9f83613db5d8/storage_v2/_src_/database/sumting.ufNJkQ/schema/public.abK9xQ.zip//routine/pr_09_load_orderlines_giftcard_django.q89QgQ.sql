create procedure pr_09_load_orderlines_giftcard_django()
    language sql
as
$$
    -- INCREMENTAL
 INSERT INTO public.pr_orderline_giftcard(
	order_key,
	notes, 
	order_id_ext, 
	orderline_id_ext, 
	orderline_id_ext_long,
	amount_line,
	created_at, 
	updated_at,   
	expirated_at) 


SELECT 	
	ord.order_key,
	notes, 
	order_id,
	ol.id,
	stripe_line_item_id, 
	cast(substring( ol.notes from position('€' in ol.notes)+1 for 2) as double precision) as amount_line,
	ol.created_at,
	ol.updated_at,
	TO_Date('9999-12-31','yyyy-mm-dd')

FROM public.lz_orders_orderitem ol

INNER JOIN lz_products_product pr
	ON pr.id=ol.product_id
LEFT JOIN pr_order ord
	ON ol.order_id=ord.order_id_ext
WHERE ord.order_type_key=1
	AND lower(pr.title) like '%gift%'
	AND ord.order_id_ext IS NULL

$$;

alter procedure pr_09_load_orderlines_giftcard_django() owner to sumting;

