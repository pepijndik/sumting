create procedure pr_01_load_payer_django()
    language sql
as
$$
-- INCREMENTAL

INSERT INTO public.pr_payer(
	payer_id_ext, 
	email, 
	created_at, 
	updated_at, 
	country, 
	name,
	type) 

SELECT 
	id, 
	lower(lz_cus.email), 
	lz_cus.created_at, 
	lz_cus.updated_at,
	lz_cus.country, 
	lz_cus.name,
	lz_cus.customer_type
	
	FROM public.lz_customers_customer lz_cus
LEFT JOIN public.pr_payer pay
ON lower(lz_cus.email)=lower(pay.email)
WHERE pay.email IS NULL
$$;

alter procedure pr_01_load_payer_django() owner to sumting;

