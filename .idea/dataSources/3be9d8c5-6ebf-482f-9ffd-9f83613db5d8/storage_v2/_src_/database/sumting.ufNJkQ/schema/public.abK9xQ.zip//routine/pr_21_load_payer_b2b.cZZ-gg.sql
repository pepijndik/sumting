create procedure pr_21_load_payer_b2b()
    language sql
as
$$
INSERT INTO public.pr_payer(
	payer_id_ext, 
	email, 
	name,
	created_at, 
	country, 
	type) 

SELECT distinct 
	NULL::bigint as payer_id_ext, 
	lower("MAIL"), 
	"NAME",
	cast( "ORDERDATE" as date)+ '00:00:01'::time, 
	'NLD' as country, 
	'BUSINESS' as type
	FROM public.lz_b2b_orders ord
	LEFT JOIN pr_payer pay
	ON lower(ord."MAIL") = lower(pay.email)
	WHERE pay.email IS NULL
$$;

alter procedure pr_21_load_payer_b2b() owner to sumting;

