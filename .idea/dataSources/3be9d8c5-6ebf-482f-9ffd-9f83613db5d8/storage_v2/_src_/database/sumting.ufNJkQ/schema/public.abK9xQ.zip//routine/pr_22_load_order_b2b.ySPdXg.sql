create procedure pr_22_load_order_b2b()
    language sql
as
$$
INSERT INTO public.pr_order(
		order_id_ext, 
		created_at, 
    	payer_key, 
		order_date, 
		transaction_total, 
		order_type_key,
		transaction_fee, 
	 	transaction_vat) 


SELECT 
    CAST("ORDERNUMBER" as int), 
	NOW(),
	pay.payer_key,
	cast( "ORDERDATE" as date)+ '00:00:01'::time as order_date,  
	"TOTAL",	
	3 as order_type,
	"FEE",
	"VAT"
	FROM public.lz_b2b_orders ord
	inner join public.pr_payer pay
	on 	lower(ord."MAIL")=lower(pay.email)
	LEFT JOIN (select order_id_ext 
			   from pr_order 
			   where order_type_key=3 ) pr_ord
	on pr_ord.order_id_ext = CAST(ord."ORDERNUMBER" as int)
	WHERE pr_ord.order_id_ext IS NULL


$$;

alter procedure pr_22_load_order_b2b() owner to sumting;

