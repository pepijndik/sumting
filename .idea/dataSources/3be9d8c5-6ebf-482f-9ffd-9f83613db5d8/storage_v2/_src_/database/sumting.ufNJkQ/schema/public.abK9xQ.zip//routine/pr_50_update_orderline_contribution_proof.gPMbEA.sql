create procedure pr_50_update_orderline_contribution_proof()
    language sql
as
$$
UPDATE pr_orderline_contribution as con
SET 
proof_name=tmp2.filename,
proof_date=tmp2.filedatetime,
latitude=tmp2.latitude,
longitude=tmp2.longitude,
proof_large=tmp2.url,
proof_uploaded_datetime=NOW(),
batch_key=tmp2.batch_key 
-- select con.orderline_key, tmp2.*

--FROM pr_orderline_contribution as con
--INNER JOIN 
FROM
	(SELECT con.orderline_key, tmp1.*

	FROM (SELECT orderline_key,project_key,
		row_number() over (partition by project_key  order by orderline_key) as rownumber 
		FROM public.pr_orderline_contribution
		 WHERE proof_name is NULL)as con

	LEFT OUTER JOIN 
		(SELECT 
			filename, 
			img.batch_key, 
			filedatetime, 
			latitude, 
			longitude, 
			url,
			bat.project_key,
			row_number() over (partition by img.batch_key,bat.project_key  order by img.filename) as rownumber
		FROM public.lz_image_proof img
		INNER JOIN  pr_batch bat
		ON bat.batch_key=img.batch_key) as tmp1
	ON  con.project_key=tmp1.project_key
		AND con.rownumber=tmp1.rownumber
	WHERE NOT tmp1.filename is NULL) as tmp2
	WHERE con.orderline_key=tmp2.orderline_key
;
$$;

alter procedure pr_50_update_orderline_contribution_proof() owner to sumting;

