create procedure pr_00_load_all_django()
    language sql
as
$$
CALL public.pr_01_load_payer_django();
CALL public.pr_02_load_payer_ext_django();
CALL public.pr_03_load_project_django();
CALL public.pr_04_load_order_django();
CALL public.pr_05_load_orderlines_contributions_django();
CALL public.pr_06_load_new_wallet_django();
CALL public.pr_07_load_orderlines_wallet_club_django();
CALL public.pr_08_update_wallet_club_with_orderlines_wallet_club_django();
CALL public.pr_09_load_orderlines_giftcard_django();
CALL public.pr_10_load_orderlines_xxx_dump();
$$;

alter procedure pr_00_load_all_django() owner to sumting;

