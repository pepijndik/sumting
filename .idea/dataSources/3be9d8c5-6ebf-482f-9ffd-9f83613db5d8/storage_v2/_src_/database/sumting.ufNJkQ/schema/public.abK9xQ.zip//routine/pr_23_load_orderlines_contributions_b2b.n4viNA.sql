create procedure pr_23_load_orderlines_contributions_b2b()
    language sql
as
$$
INSERT INTO public.pr_orderline_contribution(
	order_key,
	order_id_ext, 
	orderline_id_ext, 
    created_at, 
	transaction_line_fee,
	transaction_line_vat,
	transaction_line_total,
	project_key	) 

SELECT 
	ord.order_key,
	 CAST (ol."ORDERNUMBER" as int),
	"ORDERLINE",
	cast( "ORDERDATE" as date)+ '00:00:01'::time as created_at,
	"FEE"/"QUANTITY" as transaction_line_fee,
	"VAT"/"QUANTITY" as transaction_line_vat,
	"TOTAL"/"QUANTITY" as transaction_line_total,
	proj.project_key
	
FROM public.lz_b2b_orderlines ol
INNER join pr_order ord
ON CAST (ol."ORDERNUMBER" as int)=ord.order_id_ext
INNER JOIN  pr_project proj
ON proj.description_long=ol."PROJECT"
LEFT JOIN ( SELECT distinct order_key
		  from pr_orderline_contribution) as con
ON con.order_key=ord.order_key
WHERE ord.order_type_key=3

;
$$;

alter procedure pr_23_load_orderlines_contributions_b2b() owner to sumting;

