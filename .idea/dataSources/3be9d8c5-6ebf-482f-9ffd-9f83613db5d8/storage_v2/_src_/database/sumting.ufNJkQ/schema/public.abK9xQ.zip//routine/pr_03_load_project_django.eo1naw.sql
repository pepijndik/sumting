create procedure pr_03_load_project_django()
    language sql
as
$$
    -- INCREMENTAL 
 
 INSERT INTO public.pr_project(
	 project_id_ext,
	 description, 
	 description_long, 
	 unit_price, 
	 created_at, 
	 updated_at, 
	 web_flow_id,
	 project_id_ext_long
	
	 ) 
 
 SELECT 
 	id, 
	replace(lower(title),'-', ' '),
	NULL,
	
	NULL,
    pr.created_at, 
	pr.updated_at,
	webflow_product_id,
	stripe_product_id

	FROM public.lz_products_product pr
	LEFT JOIN pr_project project
	ON replace(lower(pr.title),'-', ' ')=project.description
	WHERE project.project_key IS NULL
		AND lower(title) not like '%giftcard%'
		AND lower(title) not Like 'sumting club%';
$$;

alter procedure pr_03_load_project_django() owner to sumting;

