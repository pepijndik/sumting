create procedure pr_04_load_order_django()
    language sql
as
$$
-- INCREMENTAl
INSERT INTO public.pr_order(
	order_id_ext, 
	order_date,
	order_type_key, 
	payer_id_ext,
	order_ext_payment_id,
	description,
	created_at, 

	payer_key,
 	transaction_total,
	currency) 


SELECT 
	lz_ord.id , 
	lz_ord.order_date, 
	1,
	lz_ord.customer_id , 
	lz_ord.stripe_payment_intent_id, 
	lz_ord.order_description, 
	lz_ord.created_at,
	pay.payer_key,
	cast(lz_ord.amount as float),
	lz_ord.currency
	FROM public.lz_orders_order lz_ord
	INNER JOIN  public.lz_customers_customer lz_cus
		ON lz_cus.id=lz_ord.customer_id
	INNER JOIN public.pr_payer pay
		ON 	lower(lz_cus.email)=lower(pay.email)
	LEFT JOIN public.pr_order ord
	ON ord.order_ext_payment_id=lz_ord.stripe_payment_intent_id 
	WHERE ord.order_ext_payment_id IS NULL;
$$;

alter procedure pr_04_load_order_django() owner to sumting;

