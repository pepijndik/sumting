create procedure pr_08_update_wallet_club_with_orderlines_wallet_club_django()
    language sql
as
$$
UPDATE pr_wallet As wal
SET 
	balance=wal.balance+tmp.balance,
	number_total=wal.number_total+tmp.number_total,
	updated_at=NOW()
FROM 
	(SELECT 
		wallet_key,
		sum(amount_total) as balance, 
		count(*) as number_total

	 FROM public.pr_orderline_wallet_club
	 WHERE wallet_is_updated='0'
	 GROUP BY wallet_key) as tmp
WHERE wal.wallet_key=tmp.wallet_key;

UPDATE pr_orderline_wallet_club
SET wallet_is_updated='1'
WHERE wallet_is_updated='0'

$$;

alter procedure pr_08_update_wallet_club_with_orderlines_wallet_club_django() owner to sumting;

