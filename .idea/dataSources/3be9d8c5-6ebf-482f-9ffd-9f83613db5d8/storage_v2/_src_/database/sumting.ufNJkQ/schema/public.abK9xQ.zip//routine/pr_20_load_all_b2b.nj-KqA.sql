create procedure pr_20_load_all_b2b()
    language sql
as
$$
truncate table lz_b2b_orders;
truncate table lz_b2b_oderlines;
call pr_21_load_payer_b2b();
call pr_22_load_order_b2b();
call pr_23_load_orderlines_contributions_b2b();
$$;

alter procedure pr_20_load_all_b2b() owner to sumting;

