create procedure pr_05_load_orderlines_contributions_django()
    language sql
as
$$
-- INCREMENTAL

INSERT INTO public.pr_orderline_contribution(
	order_key,
	notes, 
	order_id_ext, 
	orderline_id_ext, 
	orderline_id_ext_long,
	unit_ref_line_item,
	quantity,
	price,
	transaction_line_total,
	transaction_line_fee,
	transaction_line_vat,
	  
	project_key, 
	project_id_ext,
	loaded_at
 	) 


SELECT
	ord.order_key,
	lz_ol.notes, 
	lz_ol.order_id as order_id_ext,
	CAST(lz_ol.id as char(256)) as orderline_id_ext,
	lz_ol.stripe_line_item_id as orderline_id_ext_long, 
	lz_ol.unit_reference_in_line_item,
	1 as quantity,
    NULL as price,
	cast(lz_ol.amount as float) as transaction_line_total,
	NULL as transaction_line_fee,
	NULL as transaction_line_vat,
	
	proj.project_key,
	proj.project_id_ext,
	NOW()

FROM public.lz_orders_orderitem lz_ol
INNER join pr_order ord
ON lz_ol.order_id=ord.order_id_ext 
INNER JOIN lz_products_product lz_pr
ON lz_pr.id=lz_ol.product_id
INNER JOIN  pr_project proj
ON proj.project_id_ext=lz_ol.product_id 
LEFT JOIN pr_orderline_contribution ol_con
ON ol_con.orderline_id_ext= cast(lz_ol.id as char(256))
WHERE ol_con.order_id_ext IS NULL
	AND ord.order_type_key=1 
	AND NOT lower(lz_pr.title) like '%giftcard%' 
	AND NOT lower(lz_pr.title) LIKE '%club%'
$$;

comment on procedure pr_05_load_orderlines_contributions_django() is '''Not all are loaded''. Work to be done is batchnumber';

alter procedure pr_05_load_orderlines_contributions_django() owner to sumting;

